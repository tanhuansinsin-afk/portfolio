使用说明
文件说明
  index.html   首页（关于、作品精选、档案、联系）
  works.html   “全部作品”页面（首页的“查看全部作品”按钮会跳到这里）
  app.js       所有文字（中英文）和所有作品数据，改内容主要改这个文件
  style.css    样式（颜色、字号、间距）
  images / videos / magazine   放你自己的素材

1. 双击 index.html 就能在浏览器里打开（需要联网，用来加载字体）。
   四个文件要放在同一个文件夹里。
2. 改文字：用文本编辑器打开 app.js，找到 const T={ ... }，
   en 是英文、zh 是中文，直接改引号里的内容。名字在 h1b 那一行。
3. 改作品：在 app.js 里找到 "EDIT HERE"，下面每一条 {id:...} 是一个作品。
   - url:"" 填视频 / 文章 / PDF 杂志的链接
   - img:"images/我的海报.jpg" 填你自己的图片（图片放进 images 文件夹）
   - c 的可选值：video、poster、news、magazine
   - 想加作品：复制一整条，改 id 和内容，id 不要重复。
   首页只显示最新的 6 个，其余在“全部作品”页面。
   想改首页显示的数量：在 index.html 里搜索 data-limit="6"，改数字。
3b. 放个人照片：把照片放进 images 文件夹（比如 portrait.jpg），
   然后在 index.html 里搜索 class="photo"，把整个 <div class="photo" ...>...</div> 换成：
   <div class="photo"><img src="images/portrait.jpg" alt="我的照片"></div>
   放视频：把链接填进作品的 url（YouTube / Bilibili / TikTok 都可以）。
   视频封面：截一张图放进 images，作品里加 img:"images/封面.jpg"。
   TikTok 是竖屏，作品里把 r:16/9 改成 r:9/16。
4. 改邮箱：在 index.html 里搜索 hello@example.com，全部替换成你的邮箱。
5. 改左上角的 Portfolio：在 index.html 和 works.html 里搜索 class="logo"，两处都要改。
6. 上线：把整个 site 文件夹上传到 Netlify、GitHub Pages 等静态网站托管服务即可。
