const T={
en:{menu:"Menu",nav_about:"About",nav_portfolio:"Portfolio",nav_archive:"Archive",nav_contact:"Contact",viewall:"View all work →",back:"← Back to home",works_t:"All work",c1:"Video editing",c2:"Design",c3:"Office",c4:"AI tools",c5:"Social media management",
h1a:"Hello,",h1b:"I’m <span class='hl'>Tan Huan Sin</span>.",hero_sub:"I am currently seeking a job to deepen my understanding of the mass communication industry while applying and expanding my professional skill set.",cta:"Explore my work",scroll:"Scroll",
about_t:"About",photo:"Portrait placeholder<br>Replace with your photo",
about_lead:"I am known for being calm, focused, and team-oriented, thriving in environments where coordination and mutual support are essential.",
about_bio:"As a Communication student with a strong interest in media, journalism, and digital storytelling, I have developed practical skills through academic coursework, collaborative projects, and professional experience. These experiences have strengthened my abilities in writing, digital design, content creation, and strategic communication, allowing me to bring creative ideas to life through meaningful communication.",
skills:"Skills",s1:"Video editing",s2:"Poster design",s3:"News writing",s4:"Magazine layout",interests:"Creative interests",int_p:"Reading, Video Games and TV Series.",
exp:"Background",e1t:"Universiti Malaysia Sabah (UMS), Kota Kinabalu",e1d:"Bachelor of Social Science with Honors (Communications)<br>Oct 2022 – Oct 2025<br>CGPA: 3.62/4.00",e2t:"Sin Chew Daily",e2d:"Intern, Journalist<br>Aug 2025 – Oct 2025",e3t:"Honda Weemaju Sabah",e3d:"Marketing Executive<br>Mar 2026 – Present",
port_t:"Selected work",arch_t:"Archive",arch_p:"Every project, newest first. Filter by category or open an entry for details.",
con_t:"Have a project in mind? Let’s talk.",mail_note:"",soc1:"[Instagram]",soc2:"[LinkedIn]",soc3:"[Behance]",
f_name:"Name",f_email:"Email",f_subj:"Subject",f_msg:"Message",f_send:"Send message",foot:"Designed as a personal creative archive.",
all:"All",video:"Video Editing",poster:"Poster Design",news:"News Writing",magazine:"Digital Magazine",
issue:"Issue",watch:"Watch video",viewp:"View full size",read:"Read article",readm:"Read magazine",
nolink:"No link yet. Add a URL to this project in the data list in the code.",none:"No projects in this category yet.",
req:"This field is required.",bad:"Enter a valid email address.",sent:"Opening your email app…",close:"Close",open:"Open"},
zh:{menu:"菜单",nav_about:"关于",nav_portfolio:"作品",nav_archive:"档案",nav_contact:"联系",viewall:"查看全部作品 →",back:"← 返回首页",works_t:"全部作品",c1:"剪辑",c2:"设计",c3:"办公软件",c4:"AI 工具",c5:"社交媒体管理",
h1a:"你好，",h1b:"我是 <span class='hl'>陈欢幸</span>。",hero_sub:"我目前正在找寻一份能够让我发挥自身对大众传播行业的了解，同时运用并拓展专业技能的工作。",cta:"浏览我的作品",scroll:"向下滚动",
about_t:"关于我",photo:"头像占位图<br>请替换为你的照片",
about_lead:"在职场上，我善以冷静且专注地投入工作，同时具备团队协作精神；在需要密切配合与相互支持的工作环境中，我相信自己能够发挥出最佳表现。",
about_bio:"作为一名对媒体、新闻传播及数字叙事充满热忱的传播学学生，我在学术学习、团队合作项目及实际工作中不断积累经验，逐步培养了写作、数码设计、内容创作与策略传播等方面的能力。我希望能将创意与视觉表达相结合，把想法转化为有意义且具有公众影响力的内容，并通过不同的传播形式传递信息。",
skills:"技能",s1:"视频剪辑",s2:"海报设计",s3:"新闻写作",s4:"杂志排版",interests:"创作兴趣",int_p:"读书，电子游戏及电视剧。",
exp:"背景",e1t:"马来西亚沙巴大学（UMS），亚庇",e1d:"传播学荣誉社会科学学士学位<br>2022年10月 – 2025年10月<br>CGPA：3.62/4.00",e2t:"星洲日报",e2d:"实习记者<br>2025年8月 – 2025年10月",e3t:"Honda Weemaju Sabah",e3d:"市场营销执行员<br>2026年3月 – 至今",
port_t:"精选作品",arch_t:"档案",arch_p:"所有项目按时间倒序排列。可按类别筛选，点击条目查看详情。",
con_t:"有项目想法？聊聊吧。",mail_note:"",soc1:"【Instagram】",soc2:"【LinkedIn】",soc3:"【Behance】",
f_name:"姓名",f_email:"邮箱",f_subj:"主题",f_msg:"留言",f_send:"发送留言",foot:"一个个人创意档案。",
all:"全部",video:"视频剪辑",poster:"海报设计",news:"新闻写作",magazine:"数字杂志",
issue:"期号",watch:"观看视频",viewp:"查看大图",read:"阅读文章",readm:"阅读杂志",
nolink:"暂无链接。请在代码的项目数据中添加网址。",none:"该类别暂无项目。",
req:"此项为必填。",bad:"请输入有效的邮箱地址。",sent:"正在打开邮件应用…",close:"关闭",open:"打开"}};

/* ===== EDIT HERE: add projects. url = video / article / PDF link ('' = none yet) ===== */
const P=[
{id:1,c:"video",y:2025,d:"2025-09-14",r:16/9,url:"",t:{en:"Night Market Diary",zh:"夜市日记"},s:{en:"Short documentary",zh:"纪录短片"},ds:{en:"A three-minute film cut to the sound of a city after dark. Placeholder text.",zh:"一部三分钟短片，随夜晚城市的声音剪辑而成。（占位文字）"}},
{id:2,c:"poster",y:2025,d:"2025-06-02",r:3/4,url:"",t:{en:"Quiet Summer",zh:"静谧之夏"},s:{en:"Event poster",zh:"活动海报"},ds:{en:"A type-led poster for a small music festival. Placeholder text.",zh:"为小型音乐节设计的字体主导海报。（占位文字）"}},
{id:3,c:"news",y:2025,d:"2025-03-21",r:4/3,url:"",t:{en:"The Street Stalls That Stayed",zh:"留下来的街边小摊"},s:{en:"Feature",zh:"特稿"},ds:{en:"A feature on family-run stalls in a changing neighbourhood. Placeholder text.",zh:"关于变迁街区中家庭小摊的特稿。（占位文字）"}},
{id:4,c:"magazine",y:2024,d:"2024-12-01",r:3/4,url:"",n:"03",t:{en:"Slow Issue",zh:"慢刊"},s:{en:"Digital magazine",zh:"数字杂志"},ds:{en:"A themed issue on slowing down, with essays and photography. Placeholder text.",zh:"以“慢下来”为主题的一期，含随笔与摄影。（占位文字）"}},
{id:5,c:"poster",y:2024,d:"2024-08-10",r:1,url:"",t:{en:"Open Studio",zh:"开放工作室"},s:{en:"Identity poster",zh:"形象海报"},ds:{en:"A square poster series announcing an open studio day. Placeholder text.",zh:"宣布工作室开放日的方形海报系列。（占位文字）"}},
{id:6,c:"video",y:2024,d:"2024-05-18",r:16/9,url:"",t:{en:"Campus in Motion",zh:"动感校园"},s:{en:"Promo edit",zh:"宣传剪辑"},ds:{en:"A fast-paced promo cut for a student event. Placeholder text.",zh:"为学生活动制作的快节奏宣传片。（占位文字）"}},
{id:7,c:"news",y:2023,d:"2023-11-05",r:1,url:"",t:{en:"Reading the Room: A Campus Election",zh:"读懂现场：一场校园选举"},s:{en:"News report",zh:"新闻报道"},ds:{en:"A short report on student council voting day. Placeholder text.",zh:"关于学生会投票日的简短报道。（占位文字）"}},
{id:8,c:"magazine",y:2023,d:"2023-06-15",r:3/4,url:"",n:"01",t:{en:"First Light",zh:"微光"},s:{en:"Digital magazine",zh:"数字杂志"},ds:{en:"The debut issue: a collection of small beginnings. Placeholder text.",zh:"创刊号：一组关于小小开端的故事。（占位文字）"}}
];
const CATS=["video","poster","news","magazine"],COL={video:"#FFC445",poster:"#5ECD8C",news:"#FFF6E5",magazine:"#FFC445"};
let lang="en",pf="all",af="all";
try{const s=localStorage.getItem("lang");if(s==="zh"||s==="en")lang=s}catch(e){}
const t=k=>T[lang][k]||k;
const esc=s=>String(s).replace(/[&<>"]/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[m]));
function art(p){if(p.img)return p.img;const w=600,h=Math.round(600/p.r),a=COL[p.c],b=p.c==="poster"?"#252525":p.c==="video"?"#5ECD8C":p.c==="news"?"#EAE9E3":"#252525";
 const sh=p.c==="video"?`<circle cx="${w*.7}" cy="${h*.45}" r="${h*.28}" fill="${b}"/>`:p.c==="poster"?`<circle cx="${w*.35}" cy="${h*.4}" r="${w*.26}" fill="${b}"/><rect x="${w*.2}" y="${h*.72}" width="${w*.6}" height="${h*.06}" fill="#FAF9F5"/>`:p.c==="news"?`<rect x="${w*.1}" y="${h*.12}" width="${w*.8}" height="${h*.1}" fill="#252525"/><rect x="${w*.1}" y="${h*.3}" width="${w*.5}" height="${h*.05}" fill="#5ECD8C"/><rect x="${w*.1}" y="${h*.42}" width="${w*.8}" height="${h*.04}" fill="#252525" opacity=".3"/><rect x="${w*.1}" y="${h*.5}" width="${w*.7}" height="${h*.04}" fill="#252525" opacity=".3"/>`:`<rect x="${w*.1}" y="${h*.08}" width="${w*.8}" height="${h*.12}" fill="#FAF9F5"/><circle cx="${w*.5}" cy="${h*.55}" r="${w*.25}" fill="#5ECD8C"/>`;
 return "data:image/svg+xml,"+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}"><rect width="${w}" height="${h}" fill="${a}"/>${sh}</svg>`)}
const sorted=()=>[...P].sort((a,b)=>b.d.localeCompare(a.d));
const fmt=d=>new Date(d+"T00:00:00").toLocaleDateString(lang==="zh"?"zh-CN":"en-GB",{year:"numeric",month:"short",day:"numeric"});
function filters(el,cur,set){if(!el)return;el.innerHTML=["all",...CATS].map(c=>`<button aria-pressed="${c===cur}" data-c="${c}">${t(c)}</button>`).join("");
 el.onclick=e=>{const b=e.target.closest("button");if(b){set(b.dataset.c)}}}
function grid(){if(!$("grid"))return;const lim=+$("grid").dataset.limit||999,L=sorted().filter(p=>pf==="all"||p.c===pf).slice(0,lim);
 $("grid").innerHTML=L.length?L.map((p,i)=>`<button class="item ${p.c} ${p.c==="poster"?"w3":p.c==="magazine"?"w1":p.c==="video"?"w2":""}" data-id="${p.id}" aria-label="${esc(p.t[lang])}">
 <div class="thumb"><img src="${art(p)}" alt="" loading="lazy"><span class="tag ${p.c==="video"||p.c==="magazine"?"":"y"}">${t(p.c)}</span>${p.c==="video"?'<span class="play" aria-hidden="true">▶</span>':""}</div>
 <h3>${esc(p.t[lang])}</h3><div class="meta">${esc(p.s[lang])} · ${p.y}${p.n?" · "+t("issue")+" "+p.n:""}</div></button>`).join(""):`<p class="empty">${t("none")}</p>`}
function arch(){if(!$("arch"))return;const L=sorted().filter(p=>af==="all"||p.c===af),ys=[...new Set(L.map(p=>p.y))];
 $("arch").innerHTML=ys.length?ys.map(y=>`<div class="year"><h3>${y}</h3><div>${L.filter(p=>p.y===y).map(p=>`<button class="row" data-id="${p.id}"><img src="${art(p)}" alt="" loading="lazy"><span>${esc(p.t[lang])}</span><span class="d">${fmt(p.d)}</span><span class="tag ${p.c==="video"||p.c==="magazine"?"":"y"}">${t(p.c)}</span></button>`).join("")}</div></div>`).join(""):`<p class="empty">${t("none")}</p>`}
function modal(id){const p=P.find(x=>x.id==id);if(!p)return;
 const lbl={video:"watch",poster:"viewp",news:"read",magazine:"readm"}[p.c];
 const act=p.url?`<p><a class="btn" href="${esc(p.url)}" target="_blank" rel="noopener">${t(lbl)}</a></p>`:`<div class="note">${t("nolink")}</div>`;
 $("mbody").innerHTML=`<div class="vis"><img src="${art(p)}" alt="${esc(p.t[lang])}"></div><div class="txt"><span class="tag ${p.c==="video"||p.c==="magazine"?"":"y"}">${t(p.c)}</span><h2>${esc(p.t[lang])}</h2>
 <p class="meta" style="color:var(--muted);font-size:14px">${esc(p.s[lang])} · ${fmt(p.d)}${p.n?" · "+t("issue")+" "+p.n:""}</p><p>${esc(p.ds[lang])}</p>${act}</div>`;
 $("dlg").showModal()}
const $=id=>document.getElementById(id);
function applyLang(){document.documentElement.lang=lang==="zh"?"zh-CN":"en";
 document.querySelectorAll("[data-i18n]").forEach(n=>{n.innerHTML=t(n.dataset.i18n)});
 document.querySelectorAll("#lang span").forEach(s=>s.classList.toggle("on",s.dataset.l===lang));
 $("close").setAttribute("aria-label",t("close"));
 renderF();grid();arch();if($("dlg").open)modal(curId)}
let curId=null;
function renderF(){filters($("pf"),pf,c=>{pf=c;renderF();grid()});filters($("af"),af,c=>{af=c;renderF();arch()})}
$("lang").onclick=()=>{lang=lang==="en"?"zh":"en";try{localStorage.setItem("lang",lang)}catch(e){}applyLang()};
document.addEventListener("click",e=>{const b=e.target.closest("[data-id]");if(b){curId=b.dataset.id;modal(curId)}});
$("close").onclick=()=>$("dlg").close();
$("dlg").addEventListener("click",e=>{if(e.target===$("dlg"))$("dlg").close()});
$("burger").onclick=()=>{const o=$("menu").classList.toggle("open");$("burger").setAttribute("aria-expanded",o)};
$("menu").onclick=e=>{if(e.target.closest("a"))$("menu").classList.remove("open")};
$("top-btn").onclick=()=>scrollTo({top:0});
const links=[...document.querySelectorAll("nav a.l")],secs=links.map(a=>document.querySelector(a.hash));
addEventListener("scroll",()=>{$("top-btn").classList.toggle("show",scrollY>700);let cur=-1;secs.forEach((s,i)=>{if(s&&s.getBoundingClientRect().top<140)cur=i});links.forEach((a,i)=>a.classList.toggle("on",i===cur))},{passive:true});
function toast(m){const e=$("toast");e.textContent=m;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),3200)}
$("form")&&$("form").addEventListener("submit",e=>{e.preventDefault();const f=e.target;let ok=true;
 ["name","email","subject","message"].forEach(k=>{const v=f[k].value.trim(),er=f.querySelector(`[data-for=${k}]`);let m="";
  if(!v)m=t("req");else if(k==="email"&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v))m=t("bad");er.textContent=m;if(m)ok=false});
 if(!ok)return;const b=encodeURIComponent(`${f.message.value}\n\n— ${f.name.value} (${f.email.value})`);
 toast(t("sent"));location.href=`mailto:tanhuansinsin@gmail.com?subject=${encodeURIComponent(f.subject.value)}&body=${b}`;f.reset()});
$("yr").textContent=new Date().getFullYear();
applyLang();
